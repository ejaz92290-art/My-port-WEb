'use client'

import { useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ArrowRight, Palette, Type, TrendingUp } from 'lucide-react'

interface ProjectData {
  title: string
  category: string
  color: string
  gradient: string
}

interface ProjectModalProps {
  isOpen: boolean
  onClose: () => void
  project: ProjectData | null
}

function generatePalette(baseColor: string): string[] {
  const palettes: Record<string, string[]> = {
    '#3B82F6': ['#3B82F6', '#1e40af', '#60a5fa', '#93c5fd', '#1e3a5f'],
    '#8B5CF6': ['#8B5CF6', '#4c1d95', '#a78bfa', '#c4b5fd', '#3b1f6e'],
    '#06b6d4': ['#06b6d4', '#0e7490', '#22d3ee', '#67e8f9', '#164e63'],
    '#f59e0b': ['#f59e0b', '#b45309', '#fbbf24', '#fcd34d', '#78350f'],
    '#ec4899': ['#ec4899', '#9d174d', '#f472b6', '#f9a8d4', '#831843'],
    '#10b981': ['#10b981', '#047857', '#34d399', '#6ee7b7', '#064e3b'],
    '#f43f5e': ['#f43f5e', '#881337', '#fb7185', '#fda4af', '#4c0519'],
  }
  return palettes[baseColor] || ['#3B82F6', '#1e40af', '#60a5fa', '#93c5fd', '#1e3a5f']
}

export default function ProjectModal({ isOpen, onClose, project }: ProjectModalProps) {
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    },
    [onClose]
  )

  useEffect(() => {
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown)
      document.body.style.overflow = 'hidden'
    }
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = ''
    }
  }, [isOpen, handleKeyDown])

  const palette = project ? generatePalette(project.color) : []

  const challengeTexts: Record<string, string> = {
    'Brand Identity': `The client needed a complete visual overhaul that would resonate with a younger, digitally-native audience while maintaining the brand's core values and heritage. The challenge was to create a system flexible enough to work across digital and physical touchpoints, from social media to packaging, without losing cohesion.`,
    'Web Design': `Redefining the digital presence required balancing cutting-edge interactivity with accessibility and performance. The site needed to load under 3 seconds while delivering immersive scroll-driven animations and a seamless experience across all devices and screen sizes.`,
    'Motion Design': `Creating motion graphics that could capture attention within the first 0.5 seconds of a social media scroll. The animation language needed to feel premium yet approachable, and every frame had to reinforce the brand narrative without distracting from the core message.`,
    'AI Art': `Pushing the boundaries of AI-generated visuals to create artwork that felt intentionally crafted rather than computationally derived. The challenge was to develop a unique visual language that blended algorithmic precision with human artistic sensibility.`,
    'UI/UX': `Simplifying a complex enterprise workflow into an intuitive interface that reduced onboarding time by 60%. The design needed to serve both power users and newcomers, presenting depth without overwhelming the interface.`,
    'AI Creative': `Merging traditional creative direction with AI-assisted workflows to produce campaign visuals at unprecedented scale and quality. The process needed to maintain creative control while leveraging AI's ability to explore hundreds of variations rapidly.`,
  }

  const stats = [
    { value: '40%', label: 'increase in engagement' },
    { value: '2.5M', label: 'views in first month' },
    { value: '15', label: 'industry awards' },
  ]

  const processSteps = [
    { name: 'Research', desc: 'Deep dive into brand, audience, and market landscape' },
    { name: 'Concept', desc: 'Mood boards, wireframes, and creative exploration' },
    { name: 'Design', desc: 'High-fidelity designs and interactive prototypes' },
    { name: 'Refine', desc: 'Iterative feedback loops and precision polishing' },
    { name: 'Deliver', desc: 'Final assets, guidelines, and handoff' },
  ]

  return (
    <AnimatePresence>
      {isOpen && project && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/90 backdrop-blur-xl"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Modal content */}
          <motion.div
            className="relative z-10 w-full max-w-5xl mx-4 max-h-[90vh] overflow-y-auto rounded-2xl"
            style={{ scrollbarWidth: 'thin', scrollbarColor: 'rgba(59,130,246,0.3) transparent' }}
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full glass-strong flex items-center justify-center text-white/70 hover:text-white transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X size={20} />
            </button>

            {/* Hero gradient area */}
            <div
              className="h-64 md:h-96 rounded-t-2xl relative overflow-hidden"
              style={{ background: project.gradient }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-8 left-8 md:bottom-12 md:left-12">
                <motion.p
                  className="text-xs md:text-sm uppercase tracking-[0.3em] text-white/60 mb-2 font-body"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  {project.category}
                </motion.p>
                <motion.h2
                  className="text-4xl md:text-6xl lg:text-7xl font-heading text-white"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  {project.title}
                </motion.h2>
              </div>
            </div>

            {/* Case study content */}
            <div className="bg-[#111111] rounded-b-2xl p-8 md:p-12 space-y-12">
              {/* The Challenge */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <h3 className="text-2xl md:text-3xl font-heading text-white mb-4">The Challenge</h3>
                <p className="text-white/70 font-body leading-relaxed text-sm md:text-base">
                  {challengeTexts[project.category] || challengeTexts['Brand Identity']}
                </p>
              </motion.section>

              {/* Process */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <h3 className="text-2xl md:text-3xl font-heading text-white mb-6">Process</h3>
                <div className="flex flex-col md:flex-row gap-4 md:gap-2">
                  {processSteps.map((step, i) => (
                    <div key={step.name} className="flex items-center gap-3 md:flex-col md:items-start md:flex-1">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-mono text-sm font-semibold text-white"
                        style={{ background: project.gradient }}
                      >
                        {String(i + 1).padStart(2, '0')}
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-semibold text-sm font-body">{step.name}</p>
                        <p className="text-white/40 text-xs font-body hidden md:block">{step.desc}</p>
                      </div>
                      {i < processSteps.length - 1 && (
                        <ArrowRight size={14} className="text-white/20 hidden md:block mt-2" />
                      )}
                    </div>
                  ))}
                </div>
              </motion.section>

              {/* Color Palette */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <Palette size={18} className="text-white/40" />
                  <h3 className="text-2xl md:text-3xl font-heading text-white">Color Palette</h3>
                </div>
                <div className="flex gap-3 flex-wrap">
                  {palette.map((color, i) => (
                    <div key={i} className="flex flex-col items-center gap-2">
                      <div
                        className="w-14 h-14 md:w-16 md:h-16 rounded-xl shadow-lg"
                        style={{ backgroundColor: color }}
                      />
                      <span className="text-[10px] font-mono text-white/30">{color}</span>
                    </div>
                  ))}
                </div>
              </motion.section>

              {/* Typography */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <Type size={18} className="text-white/40" />
                  <h3 className="text-2xl md:text-3xl font-heading text-white">Typography</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="glass-card rounded-xl p-6">
                    <p className="text-xs uppercase tracking-widest text-white/30 mb-2 font-body">Display</p>
                    <p className="text-3xl font-heading text-white">Bebas Neue</p>
                  </div>
                  <div className="glass-card rounded-xl p-6">
                    <p className="text-xs uppercase tracking-widest text-white/30 mb-2 font-body">Body</p>
                    <p className="text-3xl font-body text-white font-light">Inter</p>
                  </div>
                </div>
              </motion.section>

              {/* Results */}
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
              >
                <div className="flex items-center gap-2 mb-6">
                  <TrendingUp size={18} className="text-white/40" />
                  <h3 className="text-2xl md:text-3xl font-heading text-white">Results</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {stats.map((stat) => (
                    <div
                      key={stat.label}
                      className="glass-card rounded-xl p-6 text-center"
                    >
                      <p
                        className="text-4xl md:text-5xl font-heading"
                        style={{
                          background: project.gradient,
                          WebkitBackgroundClip: 'text',
                          WebkitTextFillColor: 'transparent',
                        }}
                      >
                        {stat.value}
                      </p>
                      <p className="text-xs md:text-sm text-white/40 font-body mt-2">{stat.label}</p>
                    </div>
                  ))}
                </div>
              </motion.section>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}