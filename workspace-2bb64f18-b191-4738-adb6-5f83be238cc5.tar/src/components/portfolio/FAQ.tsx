'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const faqs = [
  {
    question: 'What is your design process?',
    answer:
      "My process is a blend of strategic thinking and creative exploration. I start with deep research, move to concept development, and iterate through design until we achieve something extraordinary. Every project gets the same level of dedication and attention to detail.",
  },
  {
    question: 'How long does a typical project take?',
    answer:
      "Timelines vary based on scope. A brand identity project typically takes 4-6 weeks, while a full website design can take 6-10 weeks. I always provide a detailed timeline upfront so there are no surprises.",
  },
  {
    question: 'Do you work with international clients?',
    answer:
      "Absolutely! I've worked with clients across 15+ countries. Time zones are never a barrier — I adapt my schedule to ensure seamless communication and collaboration regardless of location.",
  },
  {
    question: "What makes your approach different?",
    answer:
      "I combine traditional design principles with AI-powered tools to create work that's both timeless and cutting-edge. This unique blend allows me to deliver results faster while maintaining the highest quality standards.",
  },
  {
    question: "What's included in a brand identity package?",
    answer:
      "A complete brand identity includes logo design, color palette, typography system, brand guidelines document, social media templates, business card design, and all source files. Everything you need to launch and maintain a consistent brand.",
  },
  {
    question: 'How do we get started?',
    answer:
      "Simply reach out through the contact form or book a discovery call. We'll discuss your vision, goals, and timeline. If we're a good fit, I'll send over a proposal within 48 hours.",
  },
];

export default function FAQ() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.faq-heading'),
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
          },
        }
      );

      gsap.fromTo(
        section.querySelector('.faq-list'),
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          delay: 0.2,
          scrollTrigger: {
            trigger: section.querySelector('.faq-list'),
            start: 'top 85%',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section id="faq" className="section-padding" ref={sectionRef}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Label */}
        <div className="mb-4 faq-heading">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-muted-foreground">
            FAQ
          </span>
        </div>

        {/* Heading */}
        <h2 className="font-heading text-5xl md:text-7xl text-white mb-12 md:mb-16 faq-heading">
          Common Questions
        </h2>

        {/* FAQ Accordion */}
        <div className="faq-list space-y-3">
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="glass-card rounded-xl px-6 data-[state=open]:border-white/10 transition-colors duration-300"
              >
                <AccordionTrigger className="text-left text-white font-medium text-base md:text-lg hover:no-underline hover:text-white/90 py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}