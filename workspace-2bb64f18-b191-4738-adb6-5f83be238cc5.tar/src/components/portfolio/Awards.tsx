'use client'

import { motion } from 'framer-motion'
import { Trophy } from 'lucide-react'

interface Award {
  platform: string
  subtitle: string
}

const awards: Award[] = [
  { platform: 'Behance', subtitle: 'Featured Artist' },
  { platform: 'Dribbble', subtitle: 'Shot of the Day' },
  { platform: 'Awwwards', subtitle: 'Site of the Day' },
  { platform: 'CSSDA', subtitle: 'Special Kudos' },
  { platform: 'FWA', subtitle: 'Mobile of the Day' },
  { platform: 'Webby Awards', subtitle: 'Best Visual Design' },
  { platform: 'Communication Arts', subtitle: 'Award of Excellence' },
]

function AwardCard({ award }: { award: Award }) {
  return (
    <div className="glass-card rounded-2xl p-6 md:p-8 min-w-[200px] md:min-w-[250px] shrink-0 flex flex-col justify-between h-[160px] md:h-[180px] group hover:border-white/10 transition-colors duration-300">
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Trophy size={16} className="text-white/30 group-hover:text-[#f59e0b] transition-colors duration-300" />
        </div>
        <h3 className="text-2xl font-heading text-white leading-none">{award.platform}</h3>
      </div>
      <p className="text-xs text-muted-foreground font-body tracking-wide uppercase">
        {award.subtitle}
      </p>
    </div>
  )
}

export default function Awards() {
  return (
    <section className="py-16 md:py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-6 mb-10 md:mb-14">
        {/* Section label */}
        <motion.p
          className="text-xs uppercase tracking-[0.4em] text-muted-foreground font-body mb-4"
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Recognition
        </motion.p>

        {/* Main heading */}
        <motion.h2
          className="text-5xl md:text-7xl font-heading text-white"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          Awards & Features
        </motion.h2>
      </div>

      {/* Marquee scrolling row */}
      <div className="overflow-hidden">
        <div className="flex gap-4 md:gap-6 w-max animate-marquee">
          {/* First set */}
          {awards.map((award) => (
            <AwardCard key={award.platform} award={award} />
          ))}
          {/* Duplicate for seamless infinite loop */}
          {awards.map((award) => (
            <AwardCard key={`${award.platform}-dup`} award={award} />
          ))}
          {/* Third set for extra smoothness on wide screens */}
          {awards.map((award) => (
            <AwardCard key={`${award.platform}-trip`} award={award} />
          ))}
        </div>
      </div>
    </section>
  )
}