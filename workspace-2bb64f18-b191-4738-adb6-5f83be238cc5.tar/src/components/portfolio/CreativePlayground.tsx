'use client';

import { useEffect, useRef } from 'react';

interface Blob {
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  radius: number;
  speed: number;
  color: string;
}

export default function CreativePlayground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const blobsRef = useRef<Blob[]>([]);
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    const section = sectionRef.current;
    if (!canvas || !section) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      const rect = section.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    resize();
    window.addEventListener('resize', resize);

    // Initialize blobs
    const rect = section.getBoundingClientRect();
    const w = rect.width;
    const h = rect.height;

    blobsRef.current = [
      { x: w * 0.3, y: h * 0.4, targetX: w * 0.3, targetY: h * 0.4, radius: 200, speed: 0.02, color: 'rgba(59, 130, 246, 0.15)' },
      { x: w * 0.7, y: h * 0.6, targetX: w * 0.7, targetY: h * 0.6, radius: 180, speed: 0.035, color: 'rgba(139, 92, 246, 0.12)' },
      { x: w * 0.5, y: h * 0.3, targetX: w * 0.5, targetY: h * 0.3, radius: 250, speed: 0.015, color: 'rgba(59, 130, 246, 0.1)' },
      { x: w * 0.4, y: h * 0.7, targetX: w * 0.4, targetY: h * 0.7, radius: 160, speed: 0.04, color: 'rgba(139, 92, 246, 0.08)' },
      { x: w * 0.6, y: h * 0.5, targetX: w * 0.6, targetY: h * 0.5, radius: 220, speed: 0.025, color: 'rgba(59, 130, 246, 0.12)' },
    ];

    const handleMouseMove = (e: MouseEvent) => {
      const canvasRect = canvas.getBoundingClientRect();
      mouseRef.current.x = e.clientX - canvasRect.left;
      mouseRef.current.y = e.clientY - canvasRect.top;
    };

    const handleTouchMove = (e: TouchEvent) => {
      const canvasRect = canvas.getBoundingClientRect();
      mouseRef.current.x = e.touches[0].clientX - canvasRect.left;
      mouseRef.current.y = e.touches[0].clientY - canvasRect.top;
    };

    section.addEventListener('mousemove', handleMouseMove);
    section.addEventListener('touchmove', handleTouchMove, { passive: true });

    const animate = () => {
      const currentRect = section.getBoundingClientRect();
      const cw = currentRect.width;
      const ch = currentRect.height;

      ctx.clearRect(0, 0, cw, ch);

      blobsRef.current.forEach((blob) => {
        // Set target based on mouse position with parallax offset
        const mx = mouseRef.current.x || cw / 2;
        const my = mouseRef.current.y || ch / 2;

        blob.targetX = mx + (blob.x - cw / 2) * 0.3;
        blob.targetY = my + (blob.y - ch / 2) * 0.3;

        // Lerp towards target
        blob.x += (blob.targetX - blob.x) * blob.speed;
        blob.y += (blob.targetY - blob.y) * blob.speed;

        // Draw radial gradient blob
        const gradient = ctx.createRadialGradient(
          blob.x,
          blob.y,
          0,
          blob.x,
          blob.y,
          blob.radius
        );
        gradient.addColorStop(0, blob.color);
        gradient.addColorStop(1, 'transparent');

        ctx.beginPath();
        ctx.arc(blob.x, blob.y, blob.radius, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();
      });

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resize);
      section.removeEventListener('mousemove', handleMouseMove);
      section.removeEventListener('touchmove', handleTouchMove);
      cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  return (
    <section ref={sectionRef} className="relative h-[60vh] md:h-[80vh] overflow-hidden">
      {/* Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full"
        aria-hidden="true"
      />

      {/* Overlay text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
        <h2 className="font-heading text-6xl sm:text-8xl md:text-9xl lg:text-[12rem] text-white opacity-[0.05] whitespace-nowrap">
          CREATIVE PLAYGROUND
        </h2>
      </div>
    </section>
  );
}