'use client'

import { motion } from 'framer-motion'
import { Star } from 'lucide-react'

interface Testimonial {
  quote: string
  name: string
  title: string
  initials: string
  gradient: string
}

const testimonials: Testimonial[] = [
  {
    quote: 'Working with this team transformed our entire brand identity. The attention to detail was extraordinary.',
    name: 'Sarah Chen',
    title: 'CEO at TechVista',
    initials: 'SC',
    gradient: 'linear-gradient(135deg, #3B82F6, #8B5CF6)',
  },
  {
    quote: "The most creative designer I've ever worked with. They don't just design — they create worlds.",
    name: 'Marcus Webb',
    title: 'CMO at NovaBrand',
    initials: 'MW',
    gradient: 'linear-gradient(135deg, #8B5CF6, #ec4899)',
  },
  {
    quote: 'Our conversion rate jumped 340% after the redesign. Pure genius.',
    name: 'Aisha Patel',
    title: 'Founder of Lumina',
    initials: 'AP',
    gradient: 'linear-gradient(135deg, #10b981, #06b6d4)',
  },
  {
    quote: 'The AI-enhanced creative approach gave us visuals we never thought possible.',
    name: 'James Rodriguez',
    title: 'Director at Quantum Media',
    initials: 'JR',
    gradient: 'linear-gradient(135deg, #f59e0b, #f43f5e)',
  },
  {
    quote: 'From concept to delivery, every pixel was perfect. Truly world-class work.',
    name: 'Emma Laurent',
    title: 'Creative Head at Maison',
    initials: 'EL',
    gradient: 'linear-gradient(135deg, #ec4899, #8B5CF6)',
  },
  {
    quote: 'They brought our vision to life in ways that exceeded every expectation.',
    name: 'David Kim',
    title: 'VP Design at Helix',
    initials: 'DK',
    gradient: 'linear-gradient(135deg, #06b6d4, #3B82F6)',
  },
]

function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  return (
    <div className="glass-card rounded-2xl p-6 md:p-8 min-w-[300px] md:min-w-[400px] shrink-0 flex flex-col h-[240px] md:h-[260px]">
      {/* Stars */}
      <div className="flex gap-1 mb-4">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            size={14}
            className="text-[#f59e0b] fill-[#f59e0b]"
          />
        ))}
      </div>

      {/* Quote */}
      <p className="text-white/90 text-sm md:text-base italic font-body leading-relaxed flex-1">
        &ldquo;{testimonial.quote}&rdquo;
      </p>

      {/* Client info */}
      <div className="flex items-center gap-3 mt-4 pt-4 border-t border-white/5">
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-semibold text-white shrink-0"
          style={{ background: testimonial.gradient }}
        >
          {testimonial.initials}
        </div>
        <div>
          <p className="text-white font-semibold text-sm font-body">{testimonial.name}</p>
          <p className="text-muted-foreground text-xs font-body">{testimonial.title}</p>
        </div>
      </div>
    </div>
  )
}

export default function Testimonials() {
  return (
    <section id="testimonials" className="section-padding overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-6 mb-10 md:mb-14">
        {/* Section label */}
        <motion.p
          className="text-xs uppercase tracking-[0.4em] text-muted-foreground font-body mb-4"
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Testimonials
        </motion.p>

        {/* Main heading */}
        <motion.h2
          className="text-5xl md:text-7xl lg:text-8xl font-heading text-white"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          What Clients Say
        </motion.h2>
      </div>

      {/* Marquee scrolling testimonials */}
      <div className="overflow-hidden">
        <div className="flex gap-4 md:gap-6 w-max animate-marquee" style={{ animationDirection: 'reverse', animationDuration: '40s' }}>
          {/* First set */}
          {testimonials.map((t) => (
            <TestimonialCard key={t.name} testimonial={t} />
          ))}
          {/* Duplicate for seamless infinite loop */}
          {testimonials.map((t) => (
            <TestimonialCard key={`${t.name}-dup`} testimonial={t} />
          ))}
          {/* Third set for extra smoothness */}
          {testimonials.map((t) => (
            <TestimonialCard key={`${t.name}-trip`} testimonial={t} />
          ))}
        </div>
      </div>
    </section>
  )
}