'use client'

import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface CircularSkill {
  name: string
  percentage: number
}

interface BarSkill {
  name: string
  percentage: number
}

const circularSkills: CircularSkill[] = [
  { name: 'Photoshop', percentage: 95 },
  { name: 'Illustrator', percentage: 90 },
  { name: 'Figma', percentage: 92 },
  { name: 'After Effects', percentage: 85 },
]

const barSkills: BarSkill[] = [
  { name: 'Blender', percentage: 80 },
  { name: 'Midjourney', percentage: 88 },
  { name: 'Leonardo', percentage: 85 },
  { name: 'Premiere Pro', percentage: 82 },
]

const RADIUS = 54
const CIRCUMFERENCE = 2 * Math.PI * RADIUS

function CircularIndicator({ skill }: { skill: CircularSkill }) {
  const circleRef = useRef<SVGCircleElement>(null)
  const numberRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    if (!circleRef.current || !numberRef.current) return

    const ctx = gsap.context(() => {
      const offset = CIRCUMFERENCE - (CIRCUMFERENCE * skill.percentage) / 100

      gsap.fromTo(
        circleRef.current,
        { strokeDashoffset: CIRCUMFERENCE },
        {
          strokeDashoffset: offset,
          duration: 1.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: circleRef.current.closest('.circular-item'),
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      )

      const obj = { val: 0 }
      gsap.to(obj, {
        val: skill.percentage,
        duration: 1.8,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: circleRef.current.closest('.circular-item'),
          start: 'top 85%',
          toggleActions: 'play none none reverse',
        },
        onUpdate: () => {
          if (numberRef.current) {
            numberRef.current.textContent = Math.round(obj.val) + '%'
          }
        },
      })
    })

    return () => ctx.revert()
  }, [skill.percentage])

  return (
    <div className="circular-item flex flex-col items-center gap-4">
      <div className="relative h-36 w-36 md:h-40 md:w-40">
        <svg
          className="h-full w-full -rotate-90"
          viewBox="0 0 120 120"
          fill="none"
        >
          <defs>
            <linearGradient id={`grad-${skill.name}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3B82F6" />
              <stop offset="100%" stopColor="#8B5CF6" />
            </linearGradient>
          </defs>
          {/* Background circle */}
          <circle
            cx="60"
            cy="60"
            r={RADIUS}
            stroke="rgba(255,255,255,0.1)"
            strokeWidth="6"
            fill="none"
          />
          {/* Progress circle */}
          <circle
            ref={circleRef}
            cx="60"
            cy="60"
            r={RADIUS}
            stroke={`url(#grad-${skill.name})`}
            strokeWidth="6"
            strokeLinecap="round"
            fill="none"
            strokeDasharray={CIRCUMFERENCE}
            strokeDashoffset={CIRCUMFERENCE}
          />
        </svg>
        {/* Center text */}
        <div className="absolute inset-0 flex items-center justify-center">
          <span ref={numberRef} className="font-mono text-xl font-semibold text-white md:text-2xl">
            0%
          </span>
        </div>
      </div>
      <p className="text-sm font-medium text-muted-foreground">{skill.name}</p>
    </div>
  )
}

function SkillBar({ skill }: { skill: BarSkill }) {
  const fillRef = useRef<HTMLDivElement>(null)
  const numberRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    if (!fillRef.current || !numberRef.current) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        fillRef.current,
        { width: '0%' },
        {
          width: skill.percentage + '%',
          duration: 1.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: fillRef.current.closest('.bar-item'),
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      )

      const obj = { val: 0 }
      gsap.to(obj, {
        val: skill.percentage,
        duration: 1.6,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: fillRef.current.closest('.bar-item'),
          start: 'top 85%',
          toggleActions: 'play none none reverse',
        },
        onUpdate: () => {
          if (numberRef.current) {
            numberRef.current.textContent = Math.round(obj.val) + '%'
          }
        },
      })
    })

    return () => ctx.revert()
  }, [skill.percentage])

  return (
    <div className="bar-item">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-white">{skill.name}</span>
        <span ref={numberRef} className="font-mono text-sm text-muted-foreground">
          0%
        </span>
      </div>
      <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-white/10">
        <div
          ref={fillRef}
          className="h-full rounded-full bg-gradient-to-r from-blue-500 to-purple-500"
          style={{ width: '0%' }}
        />
      </div>
    </div>
  )
}

export default function Skills() {
  const sectionRef = useRef<HTMLElement>(null)
  const labelRef = useRef<HTMLParagraphElement>(null)
  const headingRef = useRef<HTMLHeadingElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return

    const ctx = gsap.context(() => {
      if (labelRef.current) {
        gsap.fromTo(
          labelRef.current,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: labelRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        )
      }

      if (headingRef.current) {
        gsap.fromTo(
          headingRef.current,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: headingRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        )
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section ref={sectionRef} id="skills" className="section-padding">
      <div className="mx-auto max-w-7xl px-6 md:px-8">
        {/* Section Label */}
        <p
          ref={labelRef}
          className="text-xs uppercase tracking-widest text-muted-foreground"
        >
          Skills &amp; Tools
        </p>

        {/* Main Heading */}
        <h2
          ref={headingRef}
          className="font-heading text-4xl text-white md:text-6xl lg:text-7xl mt-4"
        >
          My Arsenal
        </h2>

        {/* Part A: Circular Progress Indicators (md+ only) */}
        <div className="mt-14 hidden md:mt-16 md:grid md:grid-cols-2 lg:grid-cols-4 md:gap-8">
          {circularSkills.map((skill) => (
            <CircularIndicator key={skill.name} skill={skill} />
          ))}
        </div>

        {/* Part B: Skill Bars (all screens) */}
        <div className="mt-12 flex flex-col gap-6 md:mt-14">
          {barSkills.map((skill) => (
            <SkillBar key={skill.name} skill={skill} />
          ))}
        </div>
      </div>
    </section>
  )
}