'use client';

import { useEffect, useRef } from 'react';
import { Search, Target, Palette, Rocket } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    title: 'Discovery',
    description: 'Deep dive into your brand, audience, and goals to understand the full picture.',
    icon: Search,
  },
  {
    number: '02',
    title: 'Strategy',
    description: 'Develop a creative strategy that aligns with your business objectives.',
    icon: Target,
  },
  {
    number: '03',
    title: 'Creation',
    description: 'Bring the vision to life with cutting-edge design and technology.',
    icon: Palette,
  },
  {
    number: '04',
    title: 'Launch',
    description: 'Deliver polished, production-ready assets that make an impact.',
    icon: Rocket,
  },
];

export default function Process() {
  const sectionRef = useRef<HTMLElement>(null);
  const stepsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      stepsRef.current.forEach((step, i) => {
        if (!step) return;
        gsap.fromTo(
          step,
          { opacity: 0, x: -60 },
          {
            opacity: 1,
            x: 0,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: step,
              start: 'top 85%',
              end: 'top 50%',
              toggleActions: 'play none none reverse',
            },
            delay: i * 0.15,
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section id="process" className="section-padding" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Label */}
        <div className="mb-4">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-muted-foreground">
            Process
          </span>
        </div>

        {/* Heading */}
        <h2 className="font-heading text-5xl md:text-7xl text-white mb-16 md:mb-24">
          How I Work
        </h2>

        {/* Steps - Horizontal on desktop, vertical on mobile */}
        <div className="relative">
          {/* Desktop horizontal layout */}
          <div className="hidden md:grid md:grid-cols-4 gap-8 lg:gap-12">
            {/* Connecting lines between steps */}
            <div className="absolute top-12 left-[12.5%] right-[12.5%] h-[2px] z-0">
              <div className="line-animate w-full h-full rounded-full" />
            </div>

            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.number}
                  ref={(el) => { stepsRef.current[i] = el; }}
                  className="relative z-10 flex flex-col items-center text-center"
                >
                  {/* Numbered circle with gradient border */}
                  <div className="relative mb-6">
                    <div className="w-24 h-24 rounded-full bg-[#050505] flex items-center justify-center relative">
                      <div className="absolute inset-0 rounded-full p-[2px] bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6]">
                        <div className="w-full h-full rounded-full bg-[#050505]" />
                      </div>
                      <span className="relative z-10 font-mono text-xl font-semibold gradient-text">
                        {step.number}
                      </span>
                    </div>
                    {/* Icon above circle */}
                    <div className="absolute -top-3 -right-3 w-10 h-10 rounded-full glass-strong flex items-center justify-center">
                      <Icon className="w-5 h-5 text-[#3B82F6]" />
                    </div>
                  </div>

                  {/* Step name */}
                  <h3 className="text-xl font-semibold text-white mb-3">
                    {step.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground leading-relaxed max-w-[220px]">
                    {step.description}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Mobile vertical layout */}
          <div className="flex flex-col gap-8 md:hidden">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.number}
                  ref={(el) => { stepsRef.current[i] = el; }}
                  className="flex items-start gap-5"
                >
                  {/* Left side: number + vertical line */}
                  <div className="flex flex-col items-center shrink-0">
                    <div className="relative">
                      <div className="w-14 h-14 rounded-full bg-[#050505] flex items-center justify-center relative">
                        <div className="absolute inset-0 rounded-full p-[2px] bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6]">
                          <div className="w-full h-full rounded-full bg-[#050505]" />
                        </div>
                        <span className="relative z-10 font-mono text-sm font-semibold gradient-text">
                          {step.number}
                        </span>
                      </div>
                      <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full glass-strong flex items-center justify-center">
                        <Icon className="w-3.5 h-3.5 text-[#3B82F6]" />
                      </div>
                    </div>
                    {i < steps.length - 1 && (
                      <div className="w-[2px] h-12 mt-2 line-animate rounded-full" />
                    )}
                  </div>

                  {/* Right side: text */}
                  <div className="pt-2">
                    <h3 className="text-xl font-semibold text-white mb-2">
                      {step.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}