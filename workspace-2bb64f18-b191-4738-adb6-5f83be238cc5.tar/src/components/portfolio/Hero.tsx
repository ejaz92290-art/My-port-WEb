'use client'

import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, ChevronDown } from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null)
  const textRef = useRef<HTMLDivElement>(null)
  const artworkRef = useRef<HTMLDivElement>(null)
  const mouseRef = useRef({ x: 0, y: 0 })
  const artworkPosRef = useRef({ x: 0, y: 0 })
  const animFrameRef = useRef<number>(0)
  // Mouse parallax for artwork
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = {
        x: (e.clientX / window.innerWidth - 0.5) * 2,
        y: (e.clientY / window.innerHeight - 0.5) * 2,
      }
    }

    window.addEventListener('mousemove', handleMouseMove)

    const lerp = (a: number, b: number, n: number) => (1 - n) * a + n * b

    const animate = () => {
      artworkPosRef.current.x = lerp(artworkPosRef.current.x, mouseRef.current.x * -30, 0.05)
      artworkPosRef.current.y = lerp(artworkPosRef.current.y, mouseRef.current.y * -30, 0.05)

      if (artworkRef.current) {
        artworkRef.current.style.transform = `translate(${artworkPosRef.current.x}px, ${artworkPosRef.current.y}px)`
      }

      animFrameRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      cancelAnimationFrame(animFrameRef.current)
    }
  }, [])

  // GSAP ScrollTrigger
  useEffect(() => {
    if (!textRef.current || !sectionRef.current) return

    const tl = gsap.to(textRef.current, {
      opacity: 0,
      y: -60,
      scale: 0.95,
      ease: 'power2.in',
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: 1,
      },
    })

    return () => {
      tl.scrollTrigger?.kill()
      tl.kill()
    }
  }, [])

  const scrollToWork = () => {
    const el = document.querySelector('#work')
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  const scrollToNext = () => {
    const el = document.querySelector('#about')
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.3,
      },
    },
  }

  const lineVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] },
    },
  }

  return (
    <section
      ref={sectionRef}
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden"
    >
      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-col items-center gap-12 px-6 pt-24 pb-16 lg:flex-row lg:items-center lg:gap-16 lg:px-8 lg:pt-0">
        {/* Left: Text Content */}
        <div className="flex flex-1 flex-col items-center text-center lg:items-start lg:text-left">
          <motion.div
            ref={textRef}
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="flex flex-col"
          >
            <motion.h1
              variants={lineVariants}
              className="font-heading text-6xl leading-none tracking-tight text-white md:text-8xl lg:text-9xl"
            >
              I DON&apos;T DESIGN.
            </motion.h1>

            <motion.h1
              variants={lineVariants}
              className="font-heading text-6xl leading-none tracking-tight md:text-8xl lg:text-9xl"
            >
              <span className="gradient-text">I CREATE</span>
            </motion.h1>

            <motion.h1
              variants={lineVariants}
              className="font-heading text-6xl leading-none tracking-tight text-white md:text-8xl lg:text-9xl"
            >
              EXPERIENCES.
            </motion.h1>

            {/* Role Labels */}
            <motion.div
              variants={lineVariants}
              className="mt-6 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 lg:justify-start"
            >
              <span className="font-body text-xs uppercase tracking-widest text-muted-foreground md:text-sm">
                Graphic Designer
              </span>
              <span className="font-body text-xs text-muted-foreground/40 md:text-sm">·</span>
              <span className="font-body text-xs uppercase tracking-widest text-muted-foreground md:text-sm">
                Creative Director
              </span>
              <span className="font-body text-xs text-muted-foreground/40 md:text-sm">·</span>
              <span className="font-body text-xs uppercase tracking-widest text-muted-foreground md:text-sm">
                AI Visual Artist
              </span>
            </motion.div>

            {/* CTA Button */}
            <motion.div
              variants={lineVariants}
              className="mt-8"
            >
              <button
                onClick={scrollToWork}
                className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full border border-white/10 bg-white/5 px-6 py-3 font-body text-sm font-medium text-white transition-all duration-300 hover:border-white/20 hover:bg-white/10"
                data-cursor-hover
              >
                <span className="relative z-10">View Projects</span>
                <ArrowRight
                  size={16}
                  className="relative z-10 transition-transform duration-300 group-hover:translate-x-1"
                />
                <div className="absolute inset-0 -z-0 bg-gradient-to-r from-blue-500/0 to-purple-500/0 transition-all duration-300 group-hover:from-blue-500/10 group-hover:to-purple-500/10" />
              </button>
            </motion.div>
          </motion.div>
        </div>

        {/* Right: Floating Artwork */}
        <div className="flex flex-1 items-center justify-center">
          <div className="relative">
            {/* Main artwork */}
            <div
              ref={artworkRef}
              className="relative h-64 w-64 rounded-3xl bg-gradient-to-br from-blue-500/30 to-purple-500/30 glass md:h-80 md:w-80 lg:h-96 lg:w-96 will-change-transform"
              data-cursor-hover
            >
              {/* Inner decorative elements */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-tr from-blue-500/10 via-transparent to-purple-500/10" />
              <div className="absolute inset-4 rounded-2xl border border-white/5" />
              <div className="absolute inset-8 rounded-xl border border-white/5" />

              {/* Rotating ring */}
              <div className="absolute inset-0 animate-spin-slow rounded-3xl border border-dashed border-white/5" />

              {/* Center icon/symbol */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20 backdrop-blur-sm md:h-24 md:w-24">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 blur-sm" />
                </div>
              </div>
            </div>

            {/* Reflection / Glow effect beneath */}
            <div className="absolute -bottom-12 left-1/2 h-24 w-3/4 -translate-x-1/2 rounded-full bg-gradient-to-r from-blue-500/20 via-purple-500/15 to-blue-500/20 blur-3xl" />

            {/* Ambient glow behind */}
            <div className="absolute -inset-8 -z-10 rounded-full bg-gradient-to-br from-blue-500/10 to-purple-500/10 blur-3xl" />
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.button
        onClick={scrollToNext}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 flex flex-col items-center gap-2"
        aria-label="Scroll down"
      >
        <span className="font-body text-[10px] uppercase tracking-[0.3em] text-muted-foreground/50">
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronDown size={20} className="text-muted-foreground/50" />
        </motion.div>
      </motion.button>
    </section>
  )
}