'use client'

import { useEffect, useRef } from 'react'

export default function CursorFollower() {
  const cursorRef = useRef<HTMLDivElement>(null)
  const posRef = useRef({ x: 0, y: 0 })
  const targetRef = useRef({ x: 0, y: 0 })
  const animFrameRef = useRef<number>(0)

  useEffect(() => {
    const cursor = cursorRef.current
    if (!cursor) return

    // Only show on non-touch devices
    const isTouchDevice =
      'ontouchstart' in window || navigator.maxTouchPoints > 0
    if (isTouchDevice) {
      cursor.style.display = 'none'
      return
    }

    const handleMouseMove = (e: MouseEvent) => {
      targetRef.current = { x: e.clientX, y: e.clientY }
    }

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement
      const interactiveEl = target.closest(
        'a, button, [role="button"], input, textarea, select, [data-cursor-hover], .card, [data-slot="button"]'
      )
      if (interactiveEl) {
        cursor.classList.add('hovering')
      } else {
        cursor.classList.remove('hovering')
      }
    }

    const lerp = (a: number, b: number, n: number) => (1 - n) * a + n * b

    const animate = () => {
      posRef.current.x = lerp(posRef.current.x, targetRef.current.x, 0.15)
      posRef.current.y = lerp(posRef.current.y, targetRef.current.y, 0.15)

      const halfSize = cursor.classList.contains('hovering') ? 30 : 10
      cursor.style.transform = `translate(${posRef.current.x - halfSize}px, ${posRef.current.y - halfSize}px)`

      animFrameRef.current = requestAnimationFrame(animate)
    }

    window.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseover', handleMouseOver)
    animate()

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseover', handleMouseOver)
      cancelAnimationFrame(animFrameRef.current)
    }
  }, [])

  return (
    <div
      ref={cursorRef}
      className="cursor-follower hidden md:block"
      aria-hidden="true"
    />
  )
}