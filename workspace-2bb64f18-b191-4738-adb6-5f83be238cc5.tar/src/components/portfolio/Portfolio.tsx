'use client'

import { useState, useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import ProjectModal from './ProjectModal'

gsap.registerPlugin(ScrollTrigger)

interface ProjectItem {
  title: string
  category: string
  height: string
  gradient: string
  color: string
}

const projects: ProjectItem[] = [
  {
    title: 'Neon Dreams',
    category: 'Brand Identity',
    height: 'h-80',
    gradient: 'linear-gradient(135deg, #3B82F6, #1e40af)',
    color: '#3B82F6',
  },
  {
    title: 'Aurora Borealis',
    category: 'Web Design',
    height: 'h-64',
    gradient: 'linear-gradient(135deg, #8B5CF6, #4c1d95)',
    color: '#8B5CF6',
  },
  {
    title: 'Cyber Pulse',
    category: 'Motion Design',
    height: 'h-72',
    gradient: 'linear-gradient(135deg, #06b6d4, #0e7490)',
    color: '#06b6d4',
  },
  {
    title: 'Digital Eden',
    category: 'AI Art',
    height: 'h-56',
    gradient: 'linear-gradient(135deg, #f59e0b, #b45309)',
    color: '#f59e0b',
  },
  {
    title: 'Void Protocol',
    category: 'Brand Identity',
    height: 'h-80',
    gradient: 'linear-gradient(135deg, #ec4899, #9d174d)',
    color: '#ec4899',
  },
  {
    title: 'Quantum Shift',
    category: 'UI/UX',
    height: 'h-64',
    gradient: 'linear-gradient(135deg, #10b981, #047857)',
    color: '#10b981',
  },
  {
    title: 'Neural Canvas',
    category: 'AI Creative',
    height: 'h-72',
    gradient: 'linear-gradient(135deg, #3B82F6, #8B5CF6)',
    color: '#3B82F6',
  },
  {
    title: 'Prism Effect',
    category: 'Motion Design',
    height: 'h-56',
    gradient: 'linear-gradient(135deg, #f43f5e, #881337)',
    color: '#f43f5e',
  },
]

function ProjectCard({
  project,
  onClick,
  index,
}: {
  project: ProjectItem
  onClick: () => void
  index: number
}) {
  return (
    <motion.div
      className="break-inside-avoid mb-6"
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay: index * 0.08, ease: [0.25, 0.46, 0.45, 0.94] }}
    >
      <motion.div
        className={`relative ${project.height} rounded-2xl overflow-hidden cursor-pointer group`}
        style={{ background: project.gradient }}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.98 }}
        transition={{ duration: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
        onClick={onClick}
        role="button"
        tabIndex={0}
        aria-label={`View project: ${project.title}`}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') onClick()
        }}
        data-cursor-hover
      >
        {/* Background subtle pattern overlay */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 30% 40%, rgba(255,255,255,0.15) 0%, transparent 50%), radial-gradient(circle at 70% 60%, rgba(255,255,255,0.1) 0%, transparent 50%)',
          }} />
        </div>

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-all duration-500" />

        {/* Content - hidden by default, slides up on hover */}
        <div className="absolute inset-0 flex flex-col justify-end p-6">
          <div className="transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500 ease-out">
            <p className="text-xs uppercase tracking-[0.3em] text-white/60 mb-1 font-body">
              {project.category}
            </p>
            <h3 className="text-2xl md:text-3xl font-heading text-white">
              {project.title}
            </h3>
          </div>
          <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-500 delay-100">
            <div className="w-10 h-10 rounded-full glass-strong flex items-center justify-center">
              <ArrowUpRight size={18} className="text-white" />
            </div>
          </div>
        </div>

        {/* Always visible: project number */}
        <div className="absolute top-4 left-4">
          <span className="text-xs font-mono text-white/20">
            {String(index + 1).padStart(2, '0')}
          </span>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default function Portfolio() {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return

    const cards = sectionRef.current.querySelectorAll('.break-inside-avoid')

    gsap.fromTo(
      cards,
      { y: 80, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.7,
        stagger: 0.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
          end: 'bottom 20%',
          toggleActions: 'play none none reverse',
        },
      }
    )

    return () => {
      ScrollTrigger.getAll().forEach((trigger) => {
        if (trigger.trigger === sectionRef.current) {
          trigger.kill()
        }
      })
    }
  }, [])

  const handleProjectClick = (project: ProjectItem) => {
    setSelectedProject(project)
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setTimeout(() => setSelectedProject(null), 300)
  }

  return (
    <section id="work" className="section-padding" ref={sectionRef}>
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        {/* Section label */}
        <motion.p
          className="text-xs uppercase tracking-[0.4em] text-muted-foreground font-body mb-4"
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Selected Works
        </motion.p>

        {/* Main heading */}
        <motion.h2
          className="text-5xl md:text-7xl lg:text-8xl font-heading text-white mb-12 md:mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          Featured Projects
        </motion.h2>

        {/* Masonry grid */}
        <div className="columns-1 md:columns-2 lg:columns-3 gap-6">
          {projects.map((project, index) => (
            <ProjectCard
              key={project.title}
              project={project}
              index={index}
              onClick={() => handleProjectClick(project)}
            />
          ))}
        </div>
      </div>

      {/* Project Modal */}
      <ProjectModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        project={
          selectedProject
            ? {
                title: selectedProject.title,
                category: selectedProject.category,
                color: selectedProject.color,
                gradient: selectedProject.gradient,
              }
            : null
        }
      />
    </section>
  )
}