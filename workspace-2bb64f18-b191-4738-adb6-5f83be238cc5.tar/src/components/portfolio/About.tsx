'use client'

import { useEffect, useRef, useCallback, useState } from 'react'
import { Camera } from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const stats = [
  { value: 150, suffix: '+', label: 'Projects' },
  { value: 25, suffix: '+', label: 'Brands' },
  { value: 10, suffix: 'M+', label: 'Views Generated' },
  { value: 8, suffix: '+', label: 'Years Experience' },
]

function AnimatedCounter({
  target,
  suffix,
  inView,
}: {
  target: number
  suffix: string
  inView: boolean
}) {
  const ref = useRef<HTMLSpanElement>(null)
  const hasAnimated = useRef(false)

  useEffect(() => {
    if (!inView || hasAnimated.current || !ref.current) return
    hasAnimated.current = true

    const obj = { val: 0 }
    const duration = 2
    gsap.to(obj, {
      val: target,
      duration,
      ease: 'power2.out',
      onUpdate: () => {
        if (ref.current) {
          ref.current.textContent = Math.round(obj.val) + suffix
        }
      },
    })
  }, [inView, target, suffix])

  return <span ref={ref}>0{suffix}</span>
}

export default function About() {
  const sectionRef = useRef<HTMLElement>(null)
  const [statsVisible, setStatsVisible] = useState(false)
  const statsRef = useRef<HTMLDivElement>(null)

  const revealElements = useRef<(HTMLDivElement | HTMLHeadingElement | HTMLParagraphElement)[]>([])

  const setRef = useCallback(
    (el: HTMLDivElement | HTMLHeadingElement | HTMLParagraphElement | null) => {
      if (el) revealElements.current.push(el)
    },
    []
  )

  useEffect(() => {
    if (!sectionRef.current) return

    // Reveal animations
    revealElements.current.forEach((el, i) => {
      gsap.fromTo(
        el,
        { opacity: 0, y: 60 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: el,
            start: 'top 85%',
            end: 'top 40%',
            toggleActions: 'play none none reverse',
          },
          delay: i * 0.1,
        }
      )
    })

    // Stats counter trigger
    if (statsRef.current) {
      ScrollTrigger.create({
        trigger: statsRef.current,
        start: 'top 80%',
        onEnter: () => {
          setStatsVisible(true)
        },
        once: true,
      })
    }

    return () => {
      ScrollTrigger.getAll().forEach((t) => {
        if (t.trigger === sectionRef.current || t.trigger === statsRef.current) {
          t.kill()
        }
      })
    }
  }, [])

  return (
    <section
      ref={sectionRef}
      id="about"
      className="section-padding"
    >
      <div className="mx-auto max-w-7xl px-6 md:px-8">
        {/* Section Label */}
        <p
          ref={setRef as (el: HTMLParagraphElement | null) => void}
          className="text-xs uppercase tracking-widest text-muted-foreground"
        >
          About
        </p>

        {/* Main Heading */}
        <h1
          ref={setRef as (el: HTMLHeadingElement | null) => void}
          className="font-heading text-4xl text-white md:text-6xl lg:text-7xl mt-4"
        >
          Design isn&apos;t decoration.
        </h1>

        {/* Sub Heading */}
        <h2
          ref={setRef as (el: HTMLHeadingElement | null) => void}
          className="font-heading text-4xl gradient-text md:text-6xl lg:text-7xl mt-2"
        >
          It&apos;s psychology.
        </h2>

        {/* Two-Column Layout */}
        <div className="mt-12 grid gap-10 md:grid-cols-2 md:mt-16 md:gap-16">
          {/* Left: Placeholder Image */}
          <div
            ref={setRef as (el: HTMLDivElement | null) => void}
            className="relative h-[300px] overflow-hidden rounded-2xl sm:h-[350px] md:h-[400px]"
          >
            {/* Gradient Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/30 to-purple-500/30" />

            {/* Glass Overlay */}
            <div className="glass absolute inset-0" />

            {/* Camera Icon */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/5 backdrop-blur-sm border border-white/10">
                <Camera className="h-8 w-8 text-white/40" />
              </div>
            </div>

            {/* Decorative corner accents */}
            <div className="absolute left-4 top-4 h-8 w-8 border-l-2 border-t-2 border-blue-500/40" />
            <div className="absolute bottom-4 right-4 h-8 w-8 border-b-2 border-r-2 border-purple-500/40" />
          </div>

          {/* Right: Story Text */}
          <div className="flex flex-col justify-center">
            <p
              ref={setRef as (el: HTMLParagraphElement | null) => void}
              className="text-sm leading-relaxed text-muted-foreground md:text-base"
            >
              I&apos;m a creative professional who sits at the intersection of design,
              psychology, and artificial intelligence. Every pixel I place, every
              transition I craft, and every brand system I build is rooted in a deep
              understanding of how humans perceive, process, and respond to visual
              information.
            </p>
            <p
              ref={setRef as (el: HTMLParagraphElement | null) => void}
              className="mt-4 text-sm leading-relaxed text-muted-foreground md:text-base"
            >
              Over the past eight years, I&apos;ve helped startups and enterprise brands
              alike transform their digital presence into immersive experiences that
              don&apos;t just look beautiful — they convert, engage, and leave lasting
              impressions. I believe great design is invisible; it guides the user
              without them ever noticing.
            </p>
            <p
              ref={setRef as (el: HTMLParagraphElement | null) => void}
              className="mt-4 text-sm leading-relaxed text-muted-foreground md:text-base"
            >
              Today, I leverage cutting-edge AI tools alongside traditional design
              craft to push creative boundaries further than ever before. The result?
              Work that feels both timeless and futuristic — designed to resonate
              deeply with the people who matter most: your audience.
            </p>
          </div>
        </div>

        {/* Stats Row */}
        <div
          ref={statsRef}
          className="mt-16 grid grid-cols-2 gap-8 md:mt-20 md:grid-cols-4 md:gap-12"
        >
          {stats.map((stat) => (
            <div key={stat.label} className="text-center md:text-left">
              <div className="font-mono text-3xl gradient-text md:text-4xl">
                <AnimatedCounter
                  target={stat.value}
                  suffix={stat.suffix}
                  inView={statsVisible}
                />
              </div>
              <p className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}