'use client';

import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function CTA() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        section.querySelector('.cta-line-1'),
        { opacity: 0, scale: 0.9, y: 30 },
        {
          opacity: 1,
          scale: 1,
          y: 0,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
          },
        }
      );

      gsap.fromTo(
        section.querySelector('.cta-line-2'),
        { opacity: 0, scale: 0.9, y: 30 },
        {
          opacity: 1,
          scale: 1,
          y: 0,
          duration: 1,
          ease: 'power3.out',
          delay: 0.15,
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
          },
        }
      );

      gsap.fromTo(
        section.querySelector('.cta-sub'),
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          delay: 0.3,
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
          },
        }
      );

      gsap.fromTo(
        section.querySelector('.cta-btn'),
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          ease: 'power3.out',
          delay: 0.45,
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 md:py-32 relative">
      {/* Background radial gradient */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 60% 50% at 50% 50%, rgba(59, 130, 246, 0.05) 0%, transparent 70%)',
        }}
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        {/* Heading Line 1 */}
        <h2 className="font-heading text-5xl md:text-7xl lg:text-8xl text-white leading-none mb-2 cta-line-1">
          Let&apos;s Build Something
        </h2>

        {/* Heading Line 2 */}
        <h2 className="font-heading text-5xl md:text-7xl lg:text-8xl gradient-text leading-none mb-6 cta-line-2">
          Unforgettable.
        </h2>

        {/* Subtext */}
        <p className="text-muted-foreground text-base md:text-lg max-w-xl mx-auto mt-6 cta-sub">
          Ready to transform your brand? Let&apos;s create something
          extraordinary together.
        </p>

        {/* CTA Button with gradient border */}
        <div className="mt-10 cta-btn inline-block">
          <div className="relative rounded-full p-[2px] bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] group">
            <button className="relative flex items-center gap-2 px-8 py-4 rounded-full bg-[#050505] text-white font-medium text-sm transition-all duration-300 group-hover:bg-transparent">
              Book Discovery Call
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}