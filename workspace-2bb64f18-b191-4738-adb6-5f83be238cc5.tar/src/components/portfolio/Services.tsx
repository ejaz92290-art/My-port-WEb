'use client'

import { useEffect, useRef, useCallback, type MouseEvent } from 'react'
import {
  Palette,
  Layout,
  Play,
  Sparkles,
  Share2,
  Compass,
  type LucideIcon,
} from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface ServiceItem {
  icon: LucideIcon
  title: string
  description: string
}

const services: ServiceItem[] = [
  {
    icon: Palette,
    title: 'Brand Identity',
    description: 'Logo, packaging, brand guidelines, visual systems',
  },
  {
    icon: Layout,
    title: 'UI/UX Design',
    description: 'Web apps, mobile apps, design systems, prototyping',
  },
  {
    icon: Play,
    title: 'Motion Design',
    description: 'Animations, transitions, video edits, micro-interactions',
  },
  {
    icon: Sparkles,
    title: 'AI Creative',
    description: 'AI art, generative design, prompt engineering',
  },
  {
    icon: Share2,
    title: 'Social Media',
    description: 'Content strategy, templates, ad creatives',
  },
  {
    icon: Compass,
    title: 'Creative Direction',
    description: 'Campaign strategy, art direction, team leadership',
  },
]

function ServiceCard({ service, index }: { service: ServiceItem; index: number }) {
  const cardRef = useRef<HTMLDivElement>(null)

  const handleMouseMove = useCallback((e: MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current
    if (!card) return

    const rect = card.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    const centerX = rect.width / 2
    const centerY = rect.height / 2

    const rotateX = ((y - centerY) / centerY) * -8
    const rotateY = ((x - centerX) / centerX) * 8

    card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`
  }, [])

  const handleMouseLeave = useCallback(() => {
    const card = cardRef.current
    if (!card) return
    card.style.transform = 'perspective(800px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)'
  }, [])

  const Icon = service.icon

  return (
    <div
      ref={cardRef}
      className="service-card glass-card group cursor-default rounded-2xl p-6 transition-shadow duration-300 md:p-8 hover:shadow-[0_0_30px_rgba(59,130,246,0.1),0_0_60px_rgba(139,92,246,0.05)]"
      style={{
        transformStyle: 'preserve-3d',
        transition: 'transform 0.2s ease-out, box-shadow 0.3s ease',
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20">
        <Icon className="h-5 w-5 text-white/80" />
      </div>
      <h3 className="mt-4 text-lg font-semibold text-white">{service.title}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{service.description}</p>
    </div>
  )
}

export default function Services() {
  const sectionRef = useRef<HTMLElement>(null)
  const headingRef = useRef<HTMLHeadingElement>(null)
  const labelRef = useRef<HTMLParagraphElement>(null)
  const gridRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return

    const ctx = gsap.context(() => {
      // Label reveal
      if (labelRef.current) {
        gsap.fromTo(
          labelRef.current,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: labelRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        )
      }

      // Heading reveal
      if (headingRef.current) {
        gsap.fromTo(
          headingRef.current,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: headingRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        )
      }

      // Cards stagger
      if (gridRef.current) {
        const cards = gridRef.current.querySelectorAll('.service-card')
        gsap.fromTo(
          cards,
          { opacity: 0, y: 60 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.12,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: gridRef.current,
              start: 'top 80%',
              toggleActions: 'play none none reverse',
            },
          }
        )
      }
    }, sectionRef)

    return () => ctx.revert()
  }, [])

  return (
    <section ref={sectionRef} id="services" className="section-padding">
      <div className="mx-auto max-w-7xl px-6 md:px-8">
        {/* Section Label */}
        <p
          ref={labelRef}
          className="text-xs uppercase tracking-widest text-muted-foreground"
        >
          Services
        </p>

        {/* Main Heading */}
        <h2
          ref={headingRef}
          className="font-heading text-4xl text-white md:text-6xl lg:text-7xl mt-4"
        >
          What I Create
        </h2>

        {/* Services Grid */}
        <div
          ref={gridRef}
          className="mt-12 grid gap-6 sm:grid-cols-2 md:mt-16 lg:grid-cols-3"
        >
          {services.map((service, index) => (
            <ServiceCard key={service.title} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}