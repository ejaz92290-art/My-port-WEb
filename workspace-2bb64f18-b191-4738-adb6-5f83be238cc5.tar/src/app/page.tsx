'use client';

import { Toaster } from '@/components/ui/sonner';
import ParticleField from '@/components/portfolio/ParticleField';
import CursorFollower from '@/components/portfolio/CursorFollower';
import Navbar from '@/components/portfolio/Navbar';
import Hero from '@/components/portfolio/Hero';
import About from '@/components/portfolio/About';
import Services from '@/components/portfolio/Services';
import Portfolio from '@/components/portfolio/Portfolio';
import Skills from '@/components/portfolio/Skills';
import Awards from '@/components/portfolio/Awards';
import Testimonials from '@/components/portfolio/Testimonials';
import Process from '@/components/portfolio/Process';
import FAQ from '@/components/portfolio/FAQ';
import Contact from '@/components/portfolio/Contact';
import CreativePlayground from '@/components/portfolio/CreativePlayground';
import CTA from '@/components/portfolio/CTA';
import Footer from '@/components/portfolio/Footer';
import SmoothScroll from '@/components/providers/SmoothScroll';

export default function Home() {
  return (
    <SmoothScroll>
      <div className="noise-overlay relative min-h-screen flex flex-col bg-[#050505]">
        {/* Background particle canvas */}
        <ParticleField />

        {/* Custom cursor */}
        <CursorFollower />

        {/* Toast notifications */}
        <Toaster richColors position="top-right" />

        {/* Navigation */}
        <Navbar />

        {/* Main content */}
        <main className="relative z-10 flex-1">
          <Hero />
          <About />
          <Services />
          <Portfolio />
          <Skills />
          <Awards />
          <Testimonials />
          <CreativePlayground />
          <Process />
          <FAQ />
          <CTA />
          <Contact />
        </main>

        {/* Footer */}
        <Footer />
      </div>
    </SmoothScroll>
  );
}